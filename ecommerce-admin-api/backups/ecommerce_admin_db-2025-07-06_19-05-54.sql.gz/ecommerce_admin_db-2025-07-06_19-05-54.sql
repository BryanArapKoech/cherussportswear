--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admins (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role_id integer,
    mfa_secret character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admins OWNER TO postgres;

--
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admins_id_seq OWNER TO postgres;

--
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    admin_id integer,
    action character varying(255) NOT NULL,
    target_resource character varying(255),
    target_id integer,
    ip_address character varying(50),
    details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    address text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: marketing_content; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_content (
    slug character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    body_html text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.marketing_content OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    price_at_purchase numeric(10,2) NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    order_date timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50) DEFAULT 'processing'::character varying NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    shipping_address text NOT NULL
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    sku character varying(100) NOT NULL,
    inventory_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    permissions jsonb
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    key character varying(100) NOT NULL,
    value jsonb NOT NULL,
    description text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admins (id, email, password_hash, role_id, mfa_secret, created_at) FROM stdin;
2	support@test.com	$2b$10$9U8ACZGEDHu2UHc9gJRzXuLiULkxgR6afXc7EjHsPSWItpEDuD2gu	2	\N	2025-06-29 21:27:36.381691+03
6	new.admin@test.com	$2b$10$jqEvT/EHMrYUjcfFcDJydOOURs5YKmqC8t5hrEHVqCAqwczl9hUHS	2	\N	2025-07-01 15:23:20.084206+03
3	usermanager@test.com	$2b$10$HrR0gCTQISfCu8gHQhZ5duYXU2mKbGYzbdVz/zz2f9FP/G3e0jh4q	2	\N	2025-07-01 14:34:57.908579+03
10	test1@test.com	$2b$10$qBOt3.NR6bIU31h9PEX/muw.Rc80CKbKaAWkZTnH.elkre6vq08xS	2	\N	2025-07-01 17:16:23.906562+03
11	strong.user@test.com	$2b$10$tosWZFK0XUDc5ExuDUKBB.ZuwXNRWVvY6TAJhIV8yKYLiSTGJIDxi	2	\N	2025-07-01 17:25:47.951843+03
12	user.to.be.audited@test.com	$2b$10$D6dOgCBpCh9sOuaG/zs3veXPyd9yMkUzomO1Cl2I7W8O8bJYPwwlq	2	\N	2025-07-04 23:22:41.248769+03
1	manager@test.com	$2b$10$9U8ACZGEDHu2UHc9gJRzXuLiULkxgR6afXc7EjHsPSWItpEDuD2gu	1	PI6DK3KAKJBDS3RPM47VQ22UOJRD6KSWNZDXK6BTLBUWGW3ONURQ	2025-06-29 21:27:36.381691+03
13	product.manager@test.com	$2b$10$eaC9dXG8jAPY7GhBDXx7B.QhlW8NNLEQnQW/1tfOJxhSy9JjblHda	3	\N	2025-07-06 15:10:17.595099+03
14	support.agent@test.com	$2b$10$6GHJyzd3kWrO8kB6MAC7bOulffFG8.1IzAbF82Y.siiUEvxO7nuYW	4	\N	2025-07-06 15:10:59.890977+03
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, admin_id, action, target_resource, target_id, ip_address, details, created_at) FROM stdin;
1	1	create_admin	admins	12	::1	{"details": {"assigned_role": 2, "created_email": "user.to.be.audited@test.com"}}	2025-07-04 23:22:41.28175+03
2	1	mfa_enabled	\N	\N	::1	\N	2025-07-05 00:11:43.9244+03
3	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-05 00:20:54.425151+03
4	3	login_success_no_mfa	\N	\N	::1	\N	2025-07-05 00:21:50.283801+03
5	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-05 00:23:37.354175+03
6	1	login_mfa_success	\N	\N	::1	\N	2025-07-05 00:26:40.154121+03
7	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-05 00:34:25.231843+03
8	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-05 00:35:52.682161+03
9	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-05 00:40:32.199961+03
10	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-06 14:50:53.131701+03
11	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-06 14:55:30.234934+03
12	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-06 14:56:44.414671+03
13	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-06 15:04:03.931049+03
14	1	login_mfa_success	\N	\N	::1	\N	2025-07-06 15:07:45.105884+03
15	1	create_admin	admins	13	::1	{"details": {"assigned_role": 3, "created_email": "product.manager@test.com"}}	2025-07-06 15:10:17.604122+03
16	1	create_admin	admins	14	::1	{"details": {"assigned_role": 4, "created_email": "support.agent@test.com"}}	2025-07-06 15:10:59.896566+03
17	14	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 15:13:26.562158+03
18	13	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 15:19:22.184274+03
19	13	create_product	products	1	::1	{"details": {"sku": "SNK-001", "name": "Test Sneaker"}}	2025-07-06 15:19:58.012395+03
20	14	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 15:54:52.853368+03
21	3	login_fail_password	\N	\N	::1	\N	2025-07-06 15:57:28.537856+03
22	3	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 15:58:05.110861+03
23	3	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 15:58:56.963252+03
24	3	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 16:02:18.651073+03
25	14	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 16:05:45.062213+03
26	14	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 16:10:20.822498+03
27	3	login_fail_password	\N	\N	::1	\N	2025-07-06 16:21:03.422733+03
28	3	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 16:21:16.832324+03
29	3	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 16:25:17.693567+03
30	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-06 16:45:55.349002+03
31	1	login_mfa_success	\N	\N	::1	\N	2025-07-06 16:47:14.613153+03
32	1	update_settings	\N	\N	::1	{"details": {"updated_keys": ["maintenance_mode", "shipping_rate"]}}	2025-07-06 16:52:14.736835+03
33	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-06 17:24:52.465677+03
34	1	login_mfa_success	\N	\N	::1	\N	2025-07-06 17:25:42.162994+03
35	13	login_fail_password	\N	\N	::1	\N	2025-07-06 17:29:04.671262+03
36	13	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 17:29:26.024942+03
37	1	login_success_password_mfa_required	\N	\N	::1	\N	2025-07-06 17:41:47.683494+03
38	1	update_content	marketing_content	\N	::1	{"details": {"slug": "homepage-banner", "new_title": "New & Improved Banner"}}	2025-07-06 17:45:06.748914+03
39	13	login_success_no_mfa	\N	\N	::1	\N	2025-07-06 17:47:17.515901+03
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, email, address, created_at) FROM stdin;
1	John Doe	john.doe@example.com	123 Main St, Anytown, USA	2025-07-06 17:01:55.285066+03
\.


--
-- Data for Name: marketing_content; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_content (slug, title, body_html, updated_at) FROM stdin;
holiday-sale	Holiday Sale Page	<h2>Our Biggest Holiday Sale Ever!</h2><p>Details coming soon.</p>	2025-07-06 17:38:53.378433+03
homepage-banner	New & Improved Banner	<h1>Winter is Coming!</h1><p>All coats are 30% off!</p>	2025-07-06 17:45:06.741337+03
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, product_id, quantity, price_at_purchase) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, customer_id, order_date, status, total_amount, shipping_address) FROM stdin;
1	1	2025-07-06 17:01:55.285066+03	delivered	199.98	123 Main St, Anytown, USA
2	1	2025-07-06 17:01:55.285066+03	shipped	99.99	123 Main St, Anytown, USA
3	1	2025-07-06 17:01:55.285066+03	processing	299.97	123 Main St, Anytown, USA
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, price, sku, inventory_count, created_at, updated_at) FROM stdin;
1	Test Sneaker	\N	99.99	SNK-001	0	2025-07-06 15:19:58.001366+03	2025-07-06 15:19:58.001366+03
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, permissions) FROM stdin;
3	product_manager	{"permissions": ["read:products", "write:products"]}
5	order_manager	{"permissions": ["read:orders", "write:orders", "read:customers", "read:products"]}
4	support_agent	{"permissions": ["read:products", "read:orders", "read:customers"]}
2	user_manager	{"permissions": ["read:admins", "create:admins", "update:admins"]}
1	super_admin	{"permissions": ["*", "read:settings", "write:settings", "read:analytics", "read:content", "write:content"]}
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (key, value, description, updated_at) FROM stdin;
site_name	"E-commerce Store"	The public name of the website.	2025-07-06 17:19:48.363637+03
maintenance_mode	false	Enable or disable the customer-facing storefront.	2025-07-06 17:19:48.363637+03
tax_rate	0.08	The default sales tax rate as a decimal.	2025-07-06 17:19:48.363637+03
shipping_rate	200	The flat rate for standard shipping in Kshs.	2025-07-06 17:19:48.363637+03
\.


--
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admins_id_seq', 14, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 39, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 1, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);


--
-- Name: admins admins_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_email_key UNIQUE (email);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: customers customers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_email_key UNIQUE (email);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: marketing_content marketing_content_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_content
    ADD CONSTRAINT marketing_content_pkey PRIMARY KEY (slug);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_sku_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_key UNIQUE (sku);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: admins admins_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: audit_logs audit_logs_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id);


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- PostgreSQL database dump complete
--

